## 2.2.0（2022-03-23）
1.修复在HbuilderX Alpha版本中下拉刷新报错：`TypeError: Cannot set properties of undefined (setting 'currentIns')`的问题。  
2.修复在nvue中，空数据图始终展示在静态cell上方的问题。  
3.修复在nvue中可能出现的快速切换tab或加载更多后触发reload导致的滚动到底部view消失的bug。  
4.修复在vue3+支付宝小程序中报错的bug。  
5.`z-paging-swiper`新增`swiper-style`属性，支持设置此组件样式。  
6.新增`loading-more-default-as-loading`属性，支持设置滑动到底部状态为默认状态时，以加载中的状态展示。

